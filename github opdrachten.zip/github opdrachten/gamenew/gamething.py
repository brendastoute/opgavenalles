import random
import time

print ("You wake up in a random house that you have never seen before the only things in front of you are a gun and a knife")
vraag1= input ("you only have enough space for 1 of the items wich one do you take?\ngun,knife\n")
if vraag1 == "gun":
    print ("you have grabbed the gun and walked out the house, once your outside it seems you are alone")

if vraag1 == "knife":
    print("you have grabbed the knife and walked out the house, once your outside it seems you are alone")

vraag2 = input("you look around and see 2 things a hospital and a school nearby, where would you like to go?\nhospital,school\n")    
###################################################### under this will be the hospital route
if vraag2 == "hospital":
    print("you are walking towards the hospital and still seem nobody in sight, you walk towards the door and take a peek inside, it looks abandoned")
    vraag3= input("you walk inside an hear a noice in de distance, it sounds like metal falling, do you want to check it out?\nyes,no\n")
    if vraag3 == "yes":
        print("""you walk towards the place that seems to be making the noice
             once you get closer you hear a soft growl,you take a look behind the door and something that is not human starts atacking you!""")
        action2= input("What do you do?\nrun,attack")
        if action2 == "run":
            print("""you turn around running as fast as you can but when you reach the end of the hallway you see that the door is locked
                    you turn around only to see the creature running towards you at full speed""")
            action3 = input ("what do you do?\ntry to force the door open,fight back\n")
            if action3 == "try to force the door open":
                print("""you try bashing your body agains the door open but sadly your not strong enough
                        the creature catches up and kills you
                         the end..... try again""")
            
            if action3 == "fight back":
                print("type in attack to fight it")
                attack = random.randint(1,10)
                input (attack) 
                creature = float(5)
                if attack > creature:
                    print("""you atacked the creature and it falls down dead
                            you take a deep breath and look outside this is just the beginning of a new story
                            to be continued""")
            

                if attack < creature:
                    print("""you atempted to atack the creature but failed,........ you died
                            the end......try again""")



        
        if action2 == "attack":
            print("type in attack to fight it\n")
            print ("you run at the creature")
            timer = 5
            while timer >-1:
                time.sleep(1)
                print(timer)
                timer = timer -1
            
            attack = random.randint(1,10)
            input (attack) 
            creature = float(5)
           
            if attack > creature:
                print("""you atacked the creature and it falls down dead
                    you take a deep breath and look outside this is just the beginning of a new story
                    to be continued""")
            

            if attack < creature:
                print("""you atempted to atack the creature but failed,........ you died
                        the end......try again""")




    if vraag3 == "no":
        action= input("you decide not to check out the noice do you want to go back outside?\nyes,no\n")
        if action == "yes":
            print ("""you walk back outside and see through the window a creature waiting, you feel relieved you didn't check out the noice
                    your a little scared but understand that you gonna have to keep moving on
                    to be continued""")
        if action == "no":
            print("""you decide to stay inside where you think you are safe
                you wait and wait and wait
                so much time passes and you die of hunger and lack of water
                the end..... try again""")

        
##################################################### under this is the school route
elif vraag2 == "school":
    print ("""you walk towards the school, it seems empty
            you walk inside only to be greeted by gunpoint""")
    randomguy1 = input ("the mysterius person reloads their gun and asks WHY ARE YOU HERE?!\ni was hoping i could find people,start screaming\n")
    if randomguy1 == "i was hoping i could find people":
        print("the mysterius guy raises one eyebrow and says: your not from this place are you?")
        randomguy = input("you look at him and say\nyes i am,no\n")
        if randomguy == "yes i am":
            print("""the mysterius person laughs and says: liar..... and shoots you down
                    you died..... the end""")
        if randomguy == "no":
            print ("""i can tell well at least you didn't lie about it i would have shot you HAH
                    you want to stick with me?""")
            answer = input("you are silent for a moment and then make your decision\nyes,no\n")
            if answer == "yes":
                print("""the guy looks at you and says allright welcome
                        you walk towards the guy he grabs your hand an you both run of killing creatures as he teaches you how to fight
                            to be continued.....""")

            if answer == "no":
                print("""the random guy nods and says:i guess we both be on our way
                        you wave the guy goodbye and go on your way, you are alone now
                        goodluck
                        to be continued""")



    if randomguy1 == "start screaming":
        print ("""you starteled the random person and they accidently fire their weapon
                you died.....the end""")



import random
player1 = 10
player2 = 10
even = [2,4,6,8,10]
oneven = [1,3,5,7,9]
alles = [1,2,3,4,5,6,7,8,9,10]
print("""welcome  bij het knikker spel je begint met 10 knikkers, 
je zet een even of oneven aantal knikkers in dan moet je raden of je tegenstander een even of oneven
aantal knikkers hebt ingezet de eerste met 20 knikkers wint""")
while True:
    if player1 == 20:
        print("player1 WON")
        break
    if player2 == 20:
        print("player2 won")
        break
    game = int(input(f"hoeveel knikkers wil je inzetten\n"))
    if game <= player1 : 
        if game in even:
            keuze = input("even of oneven?\n")
            if keuze == "even": 
                aichoice= random.choice(alles) 
                if aichoice in oneven:
                    result1 = player2 + game
                    minus1= player1 - game
                    print("je verliest")
                    print(f"jij hebt nog {minus1} aantal knikkers")
                    print(f"je tegenspeler heeft {result1} aantal knikker(s)")
                if aichoice in even:
                    result2 = player1 + aichoice
                    minus2 = player2 - aichoice
                    print("je wint")
                    print(f"je tegenstander hebt nu nog {minus2}")
                    print(f"je hebt nu {result2} aantal knikkers")
                    


            elif keuze == "oneven":
                aichoice= random.choice(alles) 
                print (f"je tegenstander zet {aichoice} aantal knikker(s) in")
                if aichoice in even:
                    result3 = player2 + game
                    minus3 = player1 - game
                    print("je verliest")
                    print(f"je hebt nog {minus3} aantal knikker")
                    print(f"je tegenspeler heeft {result3} aantal knikker(s)")
                if aichoice in oneven:
                    result4 = player1 + aichoice
                    minus4 = player2 - aichoice
                    print ("je wint")
                    print(f"je tegenstander heeft not {minus4} aantal knikkers")
                    print(f"je hebt nu {result4} aantal knikkers ")

                

                aichoice = random.choice(alles)
                print (aichoice)    

        elif game in oneven:
            keuze = input("even of oneven?\n")
            if keuze == "even": 
                aichoice= random.choice(alles) 
                print (f"je tegenstander zet{aichoice} knikker(s) in")
                if aichoice in oneven:
                    result1 = player2 + game
                    minus1 = player1 - game
                    print("je verliest")
                    print(f"je tegenspeler heeft {result1} aantal knikker(s)")
                    print(f"jij hebt nog {minus1} aantal knikkers")
                if aichoice in even:
                    minus2  =player2 - aichoice
                    result2 = player1 + aichoice
                    print("je wint")
                    print(f"je tegenstander heeft {minus2} aantal knikkers")
                    print(f"je hebt nu {result2} aantal knikkers")
                    


            elif keuze == "oneven":
                aichoice= random.choice(alles) 
                print (f"je tegenstander zet {aichoice} aantal knikker(s) in")
                if aichoice in even:
                    result3 = player2 + game
                    minus3 = player1 - game
                    print("je verliest")
                    print(f"je hebt nog {minus3} aantal knikkers")
                    print(f"je tegenspeler heeft {result3} aantal knikker(s)")
                if aichoice in oneven:
                    print("je wint")
                    result4 = player1 + aichoice
                    minus4 = player2 - aichoice
                    print(f"je tegenstander heeft nu {minus4} aantal knikkers")
                    print(f"je hebt nu {result4} aantal knikker(s) ")


    else: print("zoveel knikkers heb je niet")


            

import random
spelers = []


for i in range (5):
    perdobbel = random.randint(1,6)
    spelers.append(perdobbel)
print (f"""
 1--2--3--4--5
{spelers}""")
rerolls = []
while True:
    roll1 = int(input("voor welke positie will je gaan?\n"))
    rerolls.append(roll1)
    roll = input("typ 'roll' to roll dice\n")
    if roll == "roll":
        for positie in rerolls:
            positie -= 1
            rolling = random.randint(1,6)
            spelers[positie] = rolling
            print(f"""
            1--2--3--4--5
            {spelers}""")
        again = input("wil je nog een keer rollen?\nja,nee\n")   
        if again == "ja":
            None

        elif again == "nee":
            amount2 = spelers.count(2)
            amount3 = spelers.count(3)
            amount4 = spelers.count(4)
            amount5 = spelers.count(5)
            amounttotal = [amount2,amount3,amount4,amount5]
            if amount2 == 2:
                print("PAIR")
            elif amount3 == 3:
                print("tripple")
            elif amount4 == 4:
                print("four of a kind")
            elif amount5 == 5:
                print("YATZEE")
            break

        

   
    

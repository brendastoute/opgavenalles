import random
kaarten = 108

spelers = int(input("met hoeveel spelers speel je?\n"))

blauwkaart = random.randint(1,9)
roodkaart = random.randint(1,9)
geelkaart = random.randint(1,9)
groenkaart = random.randint(1,9)

kleurkaart = [blauwkaart, roodkaart, geelkaart, groenkaart]
while True: 
    bkaart = (f"blauwe kaart {blauwkaart}")
    rkaart = (f"roode kaart {roodkaart}")
    gekaart= (f"gele kaart {geelkaart}")
    grkaart = (f"groene kaart {groenkaart}")

    aantalkaarten = spelers * 7
    if aantalkaarten > kaarten:
        print("sorry met zoveel mensen kan je niet spelen")
    



    print (random.choice(kleurkaart))
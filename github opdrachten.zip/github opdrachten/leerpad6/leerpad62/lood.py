import random
listNames = []
getrokkenlootjes = []
def loodjes():
    player = int(input("how many players are there?\n"))
    if player >= 2:
        for i in range(player):
            name= input("what is your name?\n")
            listNames.append(name) 
        lootjes = listNames.copy()
        for x in range(player):
            randomname = random.choice(lootjes)   
            lootjes.remove(randomname) 
            getrokkenlootjes.append(randomname)
    else: 
        loodjes()
    while True:
        if listNames in getrokkenlootjes:
            random.shuffle(listNames)
        else:
            print(listNames)
            print(getrokkenlootjes)
            break

    


loodjes()
#lijstaantal()
boodschappen = [] 
boodschaptotaal = []

kopen = True
while kopen :
    boodschappen = [(item) for item in input("voer in wat je wilt bestellen : ").split()]
    bestellen = input ("wilt u nog meer bestellen?\nja,nee\n")
    if bestellen == "ja":
        boodschaptotaal = [(item) for item in input("voer in wat je wilt bestellen : ").split()]
    elif bestellen == "nee":
        print("bedankt voor het shoppen") 
        print(boodschappen)
        print(boodschaptotaal)
        kopen = False
    


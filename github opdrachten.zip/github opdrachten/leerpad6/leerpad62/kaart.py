import random

allkaart= []
kleurkaart = {4 : "harten", 4: "klaveren", 4: "schoppen", 4: "ruiten", 13: "boer",13 : "vrouw", 13 :"heer",13: "aas", 2: "joker"}
kleurrandom = random.choice(list(kleurkaart.items()))
def kaarten(hoeveel):
    for x in range (hoeveel):
        kleurrandom = random.choice(list(kleurkaart.items()))
        allkaart.append(kleurrandom)
    return allkaart

hoeveel = int(input("hoeveel kaarten wil je?\n"))


print (kaarten(hoeveel))

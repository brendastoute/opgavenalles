import random
#dobbel stenen
rdobbel = random.randint(1,6)
bdobbel = random.randint(1,6)
wdobbel = random.choice([1,1,1,2,2,3])
# 2 lijsten
bluerow = [0,0,0,0,0,0,0,0-2]
redrow = [-2,0,0,0,0,0,0,0,0]
whiterow= [0,0,0,0,0]


#het resultaat dobbel stenen gooien
print (f"rodedobbel = {rdobbel}")
print (f"blauwedobbel = {bdobbel}")
print (f"wittedobbel = {wdobbel}")

#berekening
resultaat1 = (rdobbel + bdobbel + wdobbel)
resultaat2 = (rdobbel + bdobbel - wdobbel)
resultaat3 = (bdobbel + rdobbel)

resulatenlijst = [resultaat1,resultaat2,resultaat3]

#invoer spell
dobbelen = int(input("typ een getal in\n"))
if dobbelen in resulatenlijst:
    print ("nice")
else: 
    print("dumb")
import random
mm = ["oranje","blauw","groen","bruin"]
zak = []


def mmzak(aantal):

    for i in range(aantal):
        mmkeus = random.choice(mm)
        zak.append(mmkeus)
    return zak
    
    
aantal = int(input("hoeveel m&m wilt je?\n"))


print (mmzak(aantal))
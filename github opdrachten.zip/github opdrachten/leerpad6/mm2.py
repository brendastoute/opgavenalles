import random
zak = []
randommm = {
    "1" : "roze",
    "1" : "wit",
    "1" : "zwart",
    "1" : "geel",
}
mmrandom = random.choice(list(randommm.items()))


def mm(aantal):
    for i in range(aantal):
        global mmrandom
        mmrandom = random.choice(list(randommm.items()))
        zak.append(mmrandom)
    return zak

aantal = int(input("hoeveel m&m wilt u?\n"))

print (mm(aantal))



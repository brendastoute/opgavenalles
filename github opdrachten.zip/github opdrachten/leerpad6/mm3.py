import random

zakmm = {"groen" : 0, "blauw" : 0 , "orange" : 0, "bruin":0}
dictionerysmaak = {"smaken": ["groen","blauw","orange","bruin"]}

def mm(aantal):
    var1= 0
    var2 = 0
    var3 = 0
    var4 = 0
    for i in range(aantal):
        smaak = random.choice(dictionerysmaak["smaken"])  
        if smaak == "groen":
            var1 = (var1 +1)
        elif smaak == "blauw":
            var2= (var2 + 1)
        elif smaak == "orange":
            var3= (var3 + 1)
        elif smaak == "bruin":
            var4 =  (var4 + 1)
    zakmm ["blauw"] = var2
    zakmm ["bruin"] = var4
    zakmm ["groen"] =var1
    zakmm ["orange"] = var3        
    return zakmm

        

aantal = int(input("hoeveel m&m's will je?\n "))

print (mm(aantal))
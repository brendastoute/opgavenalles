def printDouble():
    return 2*2
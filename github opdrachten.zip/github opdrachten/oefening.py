import random
ran = random.random()
print (ran)

#random.random gives your a random number starting from 0


ran2 = random.randrange(1,60000)
print (ran2)

#random.randrange gives you a number between start , end of the number


letters = ('mentos','keyboard','clock')
ran3 = random.choice(letters)
print (ran3)

#random.choice chooses one object out of a list

password = ""



import string
ran4 = string.ascii_letters
for i in range (7): 
    ran5= random.choice(ran4)
    password += ran5
print (password)
# += zorg ervoor dat die de waarde van password behoud    






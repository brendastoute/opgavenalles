croissant = 0.39
stokbroden = 2.78
kortingsbon = 0.50

print (croissant * 7 + (stokbroden *2 ) - (kortingsbon * 3)  )




toegansticket = 22.35
vipgameseat = 3.33


eten = (toegansticket + vipgameseat)
b= 44.44

if eten > b:
  print("correct")
else:
    print ("Dit geweldige dagje-uit met 4 mensen in de Speelhal met 45 minuten VR kost je maar 44.44 euro")

croissant = 6.63
stokbroden = 5.56
kortingsbon = 1.50
alles = 10.69

eten = (croissant + stokbroden - kortingsbon)
b= 18.88

if eten < b:
  print("correct")
else:
  print("De feestlunch kost je bij de bakker 18.88 euro voor de 17 croissantjes en de 2 stokbroden als de 3 kortingsbonnen nog geldig zijn")

a= 10.69
b= int(a)
print(b)
#output: 10




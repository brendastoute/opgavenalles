print(1*1)
print(1*2)
print(1*3)
print(1*4)
print(1*5)
print(1*6)
print(1*7)
print(1*8)
print(1*9)
print(1*10)





#print elke tell en print de lancering

for x in range(30, 0, -1):
    print (x)


print ("rocket launces")



print ( """ 
1 am
2 am
3 am
4 am
5 am
6 am
7 am
8 am
9 am
10 am
11 am
12 am
13 pm 
14 pm
15 pm
16 pm
17 pm
18 pm
19 pm 
20 pm 
21 pm 
22 pm """)

###############################
fruits = [20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50]
for x in fruits:
  print(x)








from RobotArm import RobotArm

robotArm = RobotArm('exercise 6')
for i in range(7):
    robotArm.moveRight()


robotArm.grab()
robotArm.moveRight()
robotArm.drop()

robotArm.moveLeft()
robotArm.moveLeft()
for i in range(7):
    robotArm.grab()
    robotArm.moveRight()
    robotArm.drop()
    robotArm.moveLeft()
    robotArm.moveLeft()

    
    

robotArm.wait()
from RobotArm import RobotArm

robotArm = RobotArm('exercise 4')

for i in range(3):
    robotArm.grab()
    robotArm.moveRight()
    robotArm.drop()
    robotArm.moveLeft()
    print (i)


robotArm.moveRight()


for i in range(3):
    robotArm.grab()
    robotArm.moveRight()
    robotArm.drop()
    robotArm.moveLeft()



robotArm.wait()
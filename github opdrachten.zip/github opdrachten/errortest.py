

pRint ( hello)


print ('hello)


imput hahah





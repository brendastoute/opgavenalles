add = int(input("give me a number\n"))
add2 = int(input("give me another number\n"))


print ("the numbers together are:")
addition = print (add + add2)

print ("the numbers subtracted are:")
subtraction = print (add - add2)

print("the numbers multiplied are:")
multiplication = print (add * add2)

print("the numbers devided are:")
division = print (add / add2)

print("both numbers plus 1 =")
increment = print (add + 1)
print (add2 + 1)

print("bot number minus 1 = ")
decrement = print (add - 1)
print (add2 - 1)
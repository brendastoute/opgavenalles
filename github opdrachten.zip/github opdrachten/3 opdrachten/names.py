this = True
while this:
    name = input("what is your name?\n")
    age = input("what is your age?\n")
    questions = [name, age]
    if questions == "":
        print ("ok")
    if name == "stop":
        this = False
    if age == "stop":
        this = False



    
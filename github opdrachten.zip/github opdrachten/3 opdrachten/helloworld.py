answer = int(input("how many times?\n"))
helloworld= print ("helloworld!\n" * answer)
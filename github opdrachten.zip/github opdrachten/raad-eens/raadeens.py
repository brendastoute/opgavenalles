print("welcome by the number game your gonna have to guess a random number between 0 and 1000")
print("once you are correct you will move to the next round")

####################################################################################################
game = True
while game:
    quit= input("type 'quit' at any time if you want to end the game\n type ok to continue\n")
    round1 = True
    while round1:
        answer = float(input("type a number\n"))
        if answer == float(24):
            print("correct")
            print("1 point")
            round1 = False

        if answer < float(24):

            print ("higher")
        if answer > float(24):
            print ("lower")          
        else:
            print("again\n") 

##########################################################################################
    question = input("another round?\nyes,no\n")
    if question == "yes":
        print("round 2")
        round2 = True
        while round2:
            answer2 = float(input("type a number\n"))
            if answer == float(267):
                print("correct")
                print("2 points")
                round2 = False

            if answer < float(267):

                print ("higher")
            if answer > float(267):
                print ("lower")          
            else:
                print("again\n") 
    question2= input("another round?\nyes,no\n")
    if question2 == "yes":
        print("round 3")



        if quit == "quit":
        
            game = False
#######################################################################################





        
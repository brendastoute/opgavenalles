from RobotArm import RobotArm
robotArm = RobotArm('exercise 9')
robotArm.speed = 3    
for i in range (3):
    for i in range (4):
        robotArm.grab()
        robotArm.moveRight()   
        robotArm.drop()
    for i in range(3):
        robotArm.moveLeft()  
    for i in range (4):
        robotArm.grab()
        robotArm.moveRight()   
        robotArm.drop()      
    for i in range(4):
        robotArm.moveLeft()    
robotArm.moveLeft
robotArm.grab() 
for i in range (3):
    for i in range(5):
        robotArm.moveRight()
    robotArm.drop
    for i in range(5):
        robotArm.moveLeft()
        robotArm.drop()
    robotArm.grab()   
robotArm.moveLeft()
robotArm.grab()
for i in range(4):
    robotArm.moveRight()    
robotArm.drop()
robotArm.wait()
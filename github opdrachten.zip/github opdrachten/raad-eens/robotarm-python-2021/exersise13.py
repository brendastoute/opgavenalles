from RobotArm import RobotArm
robotArm = RobotArm()
robotArm.randomLevel(1,7)
k = 0 
for i in range(9):
    k = k + 1 
    robotArm.grab()
    color = robotArm.scan()

    if color != "":
        for i in range(k): 
            robotArm.moveRight()
        robotArm.drop()
        for i in range(k + 1):
            robotArm.moveLeft()

robotArm.wait()
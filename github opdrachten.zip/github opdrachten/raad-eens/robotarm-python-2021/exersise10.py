from RobotArm import RobotArm
robotArm = RobotArm('exercise 10')
robotArm.speed = 3
a = 11
b = 10
for i in range(5):
    a = a -2
    b = b -2
    robotArm.grab()
    for c in range(a):
        robotArm.moveRight()
    robotArm.drop()
    for d in range(b):
        robotArm.moveLeft()    
           
robotArm.wait()
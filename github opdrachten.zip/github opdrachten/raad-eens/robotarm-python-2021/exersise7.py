from RobotArm import RobotArm

robotArm = RobotArm('exercise 7')

while True:

    for i in range (3):
            for i in range(6):
                robotArm.moveRight()
                robotArm.grab()
                robotArm.moveLeft()
                robotArm.drop()

            robotArm.moveRight()
            robotArm.moveRight()
            for i in range(6):
                robotArm.moveRight()
                robotArm.grab()
                robotArm.moveLeft()
                robotArm.drop()
            robotArm.moveRight()
            robotArm.moveRight()
    break





robotArm.speed = 30





robotArm.wait()

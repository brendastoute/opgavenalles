from RobotArm import RobotArm
robotArm = RobotArm('exercise 11')
for i in range(9):
    robotArm.grab()
    color = robotArm.scan()
    

    if color == 'white':    # als die een wit blokje heeft gaat die er een naar rechts and zet die hem neer
        for r in range(9 - i):
            robotArm.moveRight()
        robotArm.drop()
        for l in range(8 - i):
            robotArm.moveLeft()
        
    else:
        robotArm.drop()
        robotArm.moveRight()

robotArm.wait()
print(
     """
+++++++++++++++++++++++++++++++++++++++++++++++
+  Sollicitatieformulier "circus directeur"  +
+++++++++++++++++++++++++++++++++++++++++++++++
Er wordt u een aantal relevante vragen gesteld..
gelieve die naar eer en geweten in te vullen
als blijkt dat u aan de criteria voldoet komt u in
aanmerking voor een serieus sollicitatie gesprek!
ontspan maar blijf wakker, hier komen de vragen
++++++++++++++++++++++++++++++++++++++++++++++++
"""
)

notaccepted = ("sorry u voldoet niet aan de eisen")
vraag1= ("ben je In bezit van een Diploma MBO-4 ondernemen?\nja,nee\n")
vraag2= ("heb je meer dan 5 jaar ervaring met jongleren?\nja,nee\n")
vraag3= ("heb je meer dan 3 jaar praktijkervaring met acrobatiek\nja,nee\n")
vraag4 = ("ben je In bezit van een hoge hoed")
vraag5 = ("ben je of een man EN heeft Snor breder dan 10 cm OF is vrouw EN draagt rood krulhaar langer dan 20 cm\nja,nee\n ")
vraag6 = ("ben je langer dan 150 cm?\nja,nee\n")
vraag7 = ("ben je zwaarder dan 90 kg")
vraag8= ("Heeft u Certificaat “Overleven met gevaarlijk personeel\nja,nee\n")
random1= ("heeft u dieren in huis?\nja,nee\n")
random2=("woont u samen met iemand?\nja,nee\n")
ramdom3=("heeft u ooit gegamed?\nja,nee\n")
random4=("heeft u ooit aan volleyball meegedaan\nja,nee\n")
einde= ("u voldoet aan alle eisen u kunt zich aanmelden")


a = int(input(" hoeveel jaar praktijkervaring heb je met dieren-dressuur: "))
b = float (5)

if a>b:

    vraag1= input("ben je In bezit van een Diploma MBO-4 ondernemen?\nja,nee\n")
    if vraag1 == "ja":
        vraag4 = input("ben je In bezit van een hoge hoed\nja,nee\n")
        if vraag4 == "ja":
            vraag5 =input("ben je of een man EN heeft Snor breder dan 10 cm OF is vrouw EN draagt rood krulhaar langer dan 20 cm\nja,nee\n")

        if vraag4 == "nee":
            print(notaccepted) 

        if vraag5 == "ja":
            vraag6 = input("ben je langer dan 150 cm?\nja,nee\n")
            if vraag6 == "ja":
                vraag7=input("ben je zwaarder dan 90 kg?\nja,nee\n")
                if vraag7 == "ja":
                    vraag8 = input("Heeft u Certificaat “Overleven met gevaarlijk personeel\nja,nee\n")
                    if vraag8 == "ja":
                        random1= input("heeft u dieren in huis?\nja,nee\n")
                        if random1 == "ja":
                            random2= input("woont u samen met iemand?\nja,nee\n")
                            if random2 == "ja":
                                random3= input("heeft u ooit gegamed?\nja,nee\n")
                                if random3== "ja":
                                    random4 = input("heeft u ooit aan volleyball meegedaan\nja,nee\n")
                                    if random4 == "ja":
                                        print(einde)
                        if random1 == "nee":
                            random2= input("woont u samen met iemand?\nja,nee\n")
                            if random2 == "nee":
                                random3= input("heeft u ooit gegamed?\nja,nee\n")
                                if random3== "nee":
                                    random4 = input("heeft u ooit aan volleyball meegedaan\nja,nee\n")
                                    if random4 == "nee":
                                        print(einde)
                                                            






                    if vraag8 == "nee":
                        print(notaccepted)    

                if vraag7 == "nee":
                    print(notaccepted)    


        if vraag5 == "nee":
            print(notaccepted)
            


    elif vraag1 == "nee":
        print(notaccepted)




elif a<b:
    print(notaccepted)
else:
    vraag1= input("ben je In bezit van een Diploma MBO-4 ondernemen?\nja,nee\n")
    if vraag1 == "ja":
        vraag4 = input("ben je In bezit van een hoge hoed\nja,nee\n")
        if vraag4 == "ja":
            vraag5 =input("ben je of een man EN heeft Snor breder dan 10 cm OF is vrouw EN draagt rood krulhaar langer dan 20 cm\nja,nee\n")

        if vraag4 == "nee":
            print(notaccepted) 

        if vraag5 == "ja":
            vraag6 = input("ben je langer dan 150 cm?\nja,nee\n")
            if vraag6 == "ja":
                vraag7=input("ben je zwaarder dan 90 kg?\nja,nee\n")
                if vraag7 == "ja":
                    vraag8 = input("Heeft u Certificaat “Overleven met gevaarlijk personeel\nja,nee\n")
                    if vraag8 == "ja":
                        random1= input("heeft u dieren in huis?\nja,nee\n")
                        if random1 == "ja":
                            random2= input("woont u samen met iemand?\nja,nee\n")
                            if random2 == "ja":
                                random3= input("heeft u ooit gegamed?\nja,nee\n")
                                if random3== "ja":
                                    random4 = input("heeft u ooit aan volleyball meegedaan\nja,nee\n")
                                    if random4 == "ja":
                                        print(einde)
                        if random1 == "nee":
                            random2= input("woont u samen met iemand?\nja,nee\n")
                            if random2 == "nee":
                                random3= input("heeft u ooit gegamed?\nja,nee\n")
                                if random3== "nee":
                                    random4 = input("heeft u ooit aan volleyball meegedaan\nja,nee\n")
                                    if random4 == "nee":
                                        print(einde)
    
            



    















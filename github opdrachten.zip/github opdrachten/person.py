print ("welcome")

name = input ("what is your name?")
print ('hello,' + name)

adres = input ("what is your adres?")

postcode = input('what is your postcode?')

living= input ('where do you live?')


a= f""" 
----------------------------------------------------
|  Naam      : {name}                
|  Adres     : {adres}           
|  Postcode  : {postcode}                        
|  Woonplaats: {living}                          
 ----------------------------------------------------"""

print (a)






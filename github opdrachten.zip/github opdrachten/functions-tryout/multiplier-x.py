question = int(input("van welk getal wil je de tafel zien?\n"))


for i in range(1,11):
    print(question * i) 






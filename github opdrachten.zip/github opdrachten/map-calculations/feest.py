croissant = 6.63
stokbroden = 5.56
kortingsbon = 1.50
toegansticket = 22.35
vipgameseat = 3.33






calculate = (croissant + stokbroden +toegansticket +vipgameseat - kortingsbon)
print (str(calculate))



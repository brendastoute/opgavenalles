i = 1
while i < 30:
    print (i)
    i = i - 1

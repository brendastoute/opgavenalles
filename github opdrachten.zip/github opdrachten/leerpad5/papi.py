smaken = ["aardbei","chocolade","munt",]

vraagsmaak = 
number = 2
def upOne():
    global number
    number += 1

print (number)
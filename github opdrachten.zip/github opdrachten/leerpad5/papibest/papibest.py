print("Welkom bij Papi Gelato")
################## prices:
PrijsBolletjes = float(0.95)
Prijshoorntje = float(1.25)
PrijsBakje = float(0.75)
totaalhoorn = 0
totaalbak = 0

keuzehoorntje = 0
keuzebolletje = 0
keuzebakje = 0

allesmaken = ""

slagroom = float(0.50)
sprinkels = float(0.30)
caramelsaush = float (0.60)
caramelsausb= float (0.90)
prijsliter = float(9.80)



CaramelSausBakjeprijs = 0
CaramelSausHoorntjeprijs = 0
slagroomprijs = 0
sprinklesprijs = 0


totaal = 0
######smaken list
smakenkeus = ["aardbei","vanille","mint","chocolade"]

def aantalbolletje():
    global bolletjevraag
    bolletjevraag = int(input("Hoeveel bolletjes wilt u?\n"))
    if bolletjevraag <=3 :
        print("")

    elif bolletjevraag > 3 and bolletjevraag < 8:
        print(f"Dan krijgt u van mij een bakje met, {bolletjevraag}  bolletjes")

    elif bolletjevraag >= 8:
        print("sorry zulke grote bakken hebben we niet")
        aantalbolletje()
        
    else:
        print("sorry dat snap ik niet")
        aantalbolletje()


def hoorntjebakje():
    bakkenvraag = (input("wilt u het in een \n hoorntje,bakje?\n"))
    if bakkenvraag == "hoorntje":
        global totaalhoorn
        totaalhoorn = totaalhoorn + 1
        print("")
        
    elif bakkenvraag == "bakje":
        global totaalbak
        totaalbak = totaalbak + 1
        print("")
    else:
        hoorntjebakje()


def smaak():
    smaakvraag = input("wat voor smaak wilt u?\naardbei,vanille,mint,chocolade\n")
    if smaakvraag in smakenkeus:
        print ("")
    elif smaakvraag == "":
        smaak()   

def toppings():
    toppingvraag = input("welke toppings wilt u?\ngeen,slagroom,sprinkels,caramelsaus\n")
    if toppingvraag == "geen":
        print ("")
    elif toppingvraag == "slagroom":
        global slagroom
        slagroom = slagroom + 1
        return "slagroom"
    elif toppingvraag == "sprinkels":
        global sprinkels
        sprinkels = sprinkels + 1
    elif toppingvraag == "caramelsaus":
        print ("")


def bonnetje():
    totaalPrijs = 0
    berekingBollen = bolletjevraag * PrijsBolletjes
    berekeningHoorn = 1 * Prijshoorntje
    berekeningBak = 1 * PrijsBakje
    berekeningSlagroom = slagroom * slagroomprijs
    berekeningSprinkels = 1 * sprinklesprijs
    berekeningCarmelH = CaramelSausHoorntjeprijs * caramelsaush
    berekeningCarmelB = CaramelSausBakjeprijs * caramelsausb
    totaalPrijsTop = berekeningSlagroom +  berekeningSprinkels + berekeningCarmelH + berekeningCarmelB
    totaalPrijs = berekeningHoorn + berekeningBak + berekingBollen + totaalPrijsTop
    print('Bolletjes = ' + str(bolletjevraag) + ' x ' + str(PrijsBolletjes) + ' = '  + str(berekingBollen) )
    if totaalbak > 0:
        print('Bakjes = ' + str(totaalbak) +' x ' + str(PrijsBakje) + ' = ' + str(berekeningBak))
    if totaalhoorn > 0:
        print('Hoorntjes = ' + str(totaalhoorn) + ' x ' + str(Prijshoorntje)+ ' = ' + str(berekeningHoorn))
    if slagroom > 0 or sprinkels > 0 or caramelsausb > 0 or caramelsaush > 0:
        print('Prijs topings = ' + str(totaalPrijsTop))
    print('Prijs in totaal = ' + str(totaalPrijs))

def partorzak():
    partzakvraag = input("bent u een particulier of zakelijk?\n")
    if partzakvraag == "particulier":
        aantalbolletje()
        hoorntjebakje()
        smaak()
        toppings()
        bonnetje()
    elif partzakvraag == "zakelijk":
        litervraag = int(input("hoeveel liter wilt u?\n"))  
        smaak()
        if litervraag >=0 :
            print (litervraag * 9.80)
            print ("dan word het",litervraag * 9.80, "inclusief btw")
        if litervraag == "":
            partorzak() 
    else:
        partorzak()

partorzak()
aantalbolletje()
hoorntjebakje()
smaak()
toppings()
bonnetje()
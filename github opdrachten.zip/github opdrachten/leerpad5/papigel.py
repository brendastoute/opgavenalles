print("Welkom bij Papi Gelato.")

prijsBolletjes = 0.95
prijsHoorn = 1.25
prijsBakje = 0.75

totaalHoorn = 0
totaalBollen = 0
totaalBak = 0

allesmaken = ""

prijsSlagroom = 0.50
prijsSprinkles = 0.30
prijsCaramelSausH = 0.60
prijsCaramelSausB = 0.90
prijsLiter = 9.80

CaramelSausBakje = 0
CaramelSausHoorntje = 0
slagroom = 0
sprinkles = 0


totaalLiter = 0


def toppings():
    while True:
        toppingsInput = input('Wat voor topping wilt u: A) Geen, B) Slagroom, C) Sprinkels of D) Caramel Saus? ')
        if toppingsInput == 'A':
            return
        elif toppingsInput == 'B':
            global slagroom
            slagroom = slagroom + 1
            return 'Slagroom'
        elif toppingsInput == 'C':
            global sprinkles
            sprinkles = sprinkles + 1
            return 'Sprinkels'
        elif toppingsInput == 'D':
            return'Caramel'
    

def bonnetje():
    totaalPrijs = 0
    berekingBollen = totaalBollen * prijsBolletjes
    berekeningHoorn = totaalHoorn * prijsHoorn 
    berekeningBak = totaalBak * prijsBakje
    berekeningSlagroom = slagroom * prijsSlagroom
    berekeningSprinkels = sprinkles * prijsSprinkles
    berekeningCarmelH = prijsCaramelSausH * CaramelSausHoorntje
    berekeningCarmelB = CaramelSausBakje * prijsCaramelSausB
    totaalPrijsTop = berekeningSlagroom +  berekeningSprinkels + berekeningCarmelH + berekeningCarmelB
    totaalPrijs = berekeningHoorn + berekeningBak + berekingBollen + totaalPrijsTop

    print('Bolletjes = ' + str(totaalBollen) + ' x ' + str(prijsBolletjes) + ' = '  + str(berekingBollen) )
    if totaalBak > 0:
        print('Bakjes = ' + str(totaalBak) +' x ' + str(prijsBakje) + ' = ' + str(berekeningBak))
    if totaalHoorn > 0:
        print('Hoorntjes = ' + str(totaalHoorn) + ' x ' + str(prijsHoorn)+ ' = ' + str(berekeningHoorn))
    if slagroom > 0 or sprinkles > 0 or CaramelSausBakje > 0 or CaramelSausHoorntje > 0:
        print('Prijs topings = ' + str(totaalPrijsTop))
    print('Prijs in totaal = ' + str(totaalPrijs))
    

def hoeveelijs():
    while True:
        aantal = int(input('Hoeveel bolletjes wilt u?: '))
        if aantal < 8:
            return aantal
        else:
            print("Sorry zulke grote bakken hebben we niet!")

def YesOrNoVraag(vraag, optionsTrue = ['yes','ja', 'A', '1'], optionsFalse = ['no', 'nee', 'B', '2']):
    while True:
        antwoord = input(vraag)
        if antwoord in optionsTrue:
            return True
        elif antwoord in optionsFalse:
            return False
        else:
            print('Sorry dat is geen optie die we aanbieden...')

def smaak(smaakvraag):
    inputSmaak = input(smaakvraag)
    if inputSmaak == 'A':
        return 'Aardbei'
    elif inputSmaak == 'C':
        return 'Chocolade'
    elif inputSmaak == 'V':
        return 'Vanille'
    else:
        print('Sorry dat is geen optie die we aanbieden...')
        return smaak(smaakvraag)


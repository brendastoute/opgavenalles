aks = input ("what size pizza would you like to order?\n small,medium,large \n")
small = "a small pizza is $5.99 and 25.4 cm\n"
medium = "a medium pizza is $7.00 and  30.48cm\n"
large = "a large pizza is $9.99 and 35.56 cm\n"

s = float (5.99)
m = float (7.00)
l = float (9.99)



if aks == ("small"):
    print(small)
    hoeveelPizza = int(input("how many would you like?\n"))
    prijs = hoeveelPizza * s
    print(prijs)
    
    

if aks == ("medium"):
    print (medium)
    print ("how many would you like?\n")
    print(small)
    hoeveelPizza = int(input("how many would you like?\n"))
    prijs = hoeveelPizza * m
    print(prijs)
   

if aks == ("large"):
    print (large)
    print ("how many would you like\n")
    print(small)
    hoeveelPizza = int(input("how many would you like?\n"))
    prijs = hoeveelPizza * l
    print(prijs)


else:
    print("invalid option")    






 #########################################################






  
  
                





print ("progameren is leuk1")
print ("hallo wereld van")
print ("pppp    y     y  ttttt   h   h     oooo    nnnn")
print ('p   p    y   y     t     h   h     o  o    n  n')
print ("p   p     y  y     t     h   h     o  o    n  n ")
print ("pppp       y       t     hhhhh     o  o    n  n ")
print ("p          y       t     h   h     o  o    n  n")
print ("p          y       t     h   h     0  0    n  n ")
print ("p          y       t     h   h     0000    n  n")

# Brenda Stoute 99068581S

import time
while True:
    print('hello')
    time.sleep(0.5)
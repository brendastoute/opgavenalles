vraag = input("welke dag is het?\nmaandag,dinsdag,woensdag,donderdag,vrijdag,zaterdag,zondag\n")

while vraag == "maandag":
    print("maandag")
    break
while vraag == "dinsdag":
    print ("maandag,dinsdag")
    break
while vraag == "woensdag":
    print ("maandag,dinsdag,woensdag")
    break
while vraag == "donderdag":
    print ("maandag,dinsdag,woensdag,donderdag")
    break
while vraag == "vrijdag":
    print ("maandag,dinsdag,woensdag,donderdag,vrijdag")
    break
while vraag == "zaterdag":
    print ("maandag,dinsdag,woensdag,donderdag,vrijdag,zaterdag")
    break
while vraag == "zondag":
    print ("maandag,dinsdag,woendsag,donderdag,vrijdag,zaterdag,zondag")
    break






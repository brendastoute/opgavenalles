incorrect = True
while incorrect:
    answer = input("typ een woord\n")
    if answer == "quit":
        print("correct")
        incorrect = False
        
            
    






print ("prepare for take of")


countdown = 30
while countdown >-1:
    print(countdown)
    countdown = countdown -1


print ("rocket launches")








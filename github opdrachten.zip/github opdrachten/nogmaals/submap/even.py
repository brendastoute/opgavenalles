even = 20
other = 50
while even < other:
    other = other -2
    print (other)





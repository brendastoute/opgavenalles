cijfer = 50
eindgetal = 1000

while cijfer < eindgetal:
    cijfer = cijfer + 1
    print (cijfer)
    





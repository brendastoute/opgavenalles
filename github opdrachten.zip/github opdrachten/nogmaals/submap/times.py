am = ("am")
pm = ("pm") 

time = 12 
while time >-1:
    print(time) 
    print (am)
    time = time -1


time3 = 12
time2 = 24
while time2 > time3:
    print (time2)
    print(pm)
    time2 = time2 -1 

# name of student: Brenda
# number of student:
# purpose of program: 
# function of program:
# structure of program: 

toPay = int(float(input('Amount to pay: '))* 1) # dit  stelt een vraag en doet het getal dan * 100
payed = int(float(input('Payed amount: ')) * 1) 
change = payed - toPay #dit pakt the topay en payed en doet het min elkaar 

if change > 0: # als change groter als 0 is dan is the coinvalue 50
  coinValue = 50 # dit geeft coinvalue een value
  
  while change > 0 and coinValue > 0: #
    nrCoins = change // coinValue #deelt het getal en rond het af op gehele getallen

    if nrCoins > 0: # als nrcoins groter is als 0 dan print die dit uit
      print('return maximal ', nrCoins, ' coins of ', coinValue, ' cents!' ) #
      nrCoinsReturned = int(input('How many coins of ' + str(coinValue) +  ' cents did you return? ')) #
      change -= nrCoinsReturned * coinValue # doet het min elkaar en rekent daarvan de uitkomst en doet die x wat anders

# comment on code below: dit betekend if coinvalue 50 is dan is coinvalue 20 en elif betekend anders dus als coinvalue niet 50 is dat
    if coinValue == 50:
      coinValue = 20
    elif coinValue == 20:
      coinValue = 10
    elif coinValue == 10:
      coinValue = 5
    elif coinValue == 5:
      coinValue = 2
    elif coinValue == 2:
      coinValue = 1
    else:
      coinValue = 0

if change > 0: #als change groter is dan 0 dan gebeurd er dit en anders zegt die done
  print('Change not returned: ', str(change) + ' cents')
else:
  print('done')


print (change)




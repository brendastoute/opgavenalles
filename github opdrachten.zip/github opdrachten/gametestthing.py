import time

timer = 5
while timer >-1:
    time.sleep(1)
    print(timer)
    timer = timer -1

    if timer == 0:
        print("you lose")


    
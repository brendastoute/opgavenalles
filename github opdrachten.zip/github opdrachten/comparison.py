a= float (2)
b = float (3)




if a > b:
    print("a is bigger")


elif a < b:
    print ("b is bigger")    

else:
    print(" they are the same size")    
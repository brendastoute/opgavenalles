ask = input ("is de kaas geel?\nja,nee\n")

een = ("zitter er gaten in\nja,nee\n")
twee = ("is de kaas belachelijk duur?\nja,nee\n")
drie = ("is de kaas hard als steen?\nja,nee\n")
vier = ("heeft de kaas blauwe schimmel\nja,nee\n")
vijf = ("heeft de kaas een korst\nja,nee\n")
zes =("heeft de kaas een korst\nja,nee\n")


if ask == "ja":
   een = input("zitten er gaten in?\nja,nee\n")

if een == "ja":
    twee = input ("is de kaas belachelijk duur?\nja,nee\n")

elif een == "nee":
    drie = input ("is de kaas hard als steen?\nja,nee\n")

if twee == "ja":
    print("dan is het ementhaler!")

elif twee == "nee":
    print ("dan is het leerdammer")

if drie == "ja":
    print ("dan is het pamigiano regianno")

elif drie == "nee":
    print ("dan is het goudse kaas")

#####################################################################################
if ask == ("nee"):
    vier = input ("heeft de kaas blouwe schimmel?\nja,nee\n")

if vier == ("ja"):
    vijf = input ("heeft de kaas een korst?\nja,nee\n")

elif vier == ("nee"):
    zes = input ("heeft de kaas een korst?\nja,nee\n")

if vijf == ("ja"):
    print("dan is het blue de rochbaron")


elif vijf == ("nee"):
    print ("foume dmambert") 


if zes == ("ja"):
    print ("dan is het camembert")


elif zes == ("nee"):
    print ("dan is het mozarella")           


 


